#ifndef __MOTOR_H__
#define __MOTOR_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
#include "pid.h"



#define beipin 4
#define xianshu 13
#define jiansubi 30
#define PWM_MAX 1000
#define SPEED_MAX 4

#define CAPTURE htim2

typedef struct
{
	volatile float actual_speed;		
	volatile float target_speed;	
	
	volatile float actual_angle;	
	volatile float target_angle;		
	
	volatile int encoder_overflow;
	
	volatile int capture_count;		
	
	volatile int last_count;			
	
	volatile int pwm;				
	
	volatile uint8_t mode;
	
	PID_TypeDef k_angle;	
	PID_TypeDef k_speed;	
	PID_TypeDef k_double;	
	
	TIM_HandleTypeDef timepwm1; 
	uint16_t channelpwm1;			

	TIM_HandleTypeDef timepwm2; 
	uint16_t channelpwm2;			
  
	GPIO_TypeDef *in1_port,*in2_port;
	uint16_t in1_pin,in2_pin;
	
	uint16_t channelpwm;  
	TIM_HandleTypeDef timepwm;  
	
	TIM_HandleTypeDef encoder;
	TIM_HandleTypeDef capturetim;
	
}MOTOR_TypeDef;	

#define MOTOR_COUNT 4
extern MOTOR_TypeDef motors[MOTOR_COUNT];

extern MOTOR_TypeDef A_L,B_L,C_R,D_R;



void MOTOR_Init(void);		
void MOTOR_Tim_Init(MOTOR_TypeDef *motor);

void MOTOR_Tim_Stop(MOTOR_TypeDef *motor);

void MOTOR_reset(void);					 

float get_speed(float nms,MOTOR_TypeDef *motor);	
float get_angle(MOTOR_TypeDef *motor);	

void set_motor_pwm(MOTOR_TypeDef *motor);	
void limit_pwm_angle(MOTOR_TypeDef *motor);		
void limit_speed(MOTOR_TypeDef *motor);		
void check_pwm_speed(MOTOR_TypeDef *motor);	
void feedback_angle(MOTOR_TypeDef *motor);	
void feedback_speed(MOTOR_TypeDef *motor);  
void feedback_angle_double(MOTOR_TypeDef *motor, float ms);
void set_multiple_motors_pwm(MOTOR_TypeDef *motors, uint8_t count);
void stop_all_motors(MOTOR_TypeDef **motors, uint8_t count);
void set_all_motor_speeds(int16_t speeds[], uint8_t count) ;

#ifdef __cplusplus
}
#endif

#endif

