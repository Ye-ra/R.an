#include "motor.h"
#include "pid.h"
#include "tim.h"
#include "delay.h"
#include "usart.h"
#include "string.h"


MOTOR_TypeDef A_L = {0};
MOTOR_TypeDef D_R = {0};
MOTOR_TypeDef B_L = {0};
MOTOR_TypeDef C_R = {0};

void MOTOR_Init(void)
{
	A_L.encoder 	= 	htim3;	//A encoder -->TIM3
	B_L .encoder  = 	htim2;	//B encoder --> TIM2
	C_R.encoder 	= 	htim8;	//C encoder --> TIM8
	D_R.encoder   = 	htim4;	//D encoder --> TIM4
		
	
	A_L.timepwm1 = htim1 ; //PWMA
	B_L.timepwm1 = htim1 ; //PWMB
	C_R.timepwm1 = htim1 ; //PWMC
	D_R.timepwm1 = htim1 ; //PWMD

	
	A_L.channelpwm1 = TIM_CHANNEL_1 ;  //PWMx -->  CHANNEL_x
	B_L.channelpwm1 = TIM_CHANNEL_2 ;
	C_R.channelpwm1 = TIM_CHANNEL_3 ;
	D_R.channelpwm1 = TIM_CHANNEL_4 ;

	
	
	__HAL_TIM_CLEAR_IT(&htim2,TIM_IT_UPDATE);	
	__HAL_TIM_SetCounter(&htim2,0);			
	HAL_TIM_Base_Start_IT(&htim2);		

	//启动TIM1所有PWM通道
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);
	// 启用TIM1主输出使能(MOE)位
	__HAL_TIM_MOE_ENABLE(&htim1);
	
	
	
	A_L.in1_port = AIN1_GPIO_Port ;	
	A_L.in2_port = AIN2_GPIO_Port ;
	

	B_L.in1_port = BIN1_GPIO_Port;
	B_L.in2_port = BIN2_GPIO_Port;
	
	C_R.in1_port = CIN1_GPIO_Port;		
	C_R.in2_port = CIN2_GPIO_Port;
	
	D_R.in1_port = DIN1_GPIO_Port;
	D_R.in2_port = DIN2_GPIO_Port;
	
	A_L.in1_pin = AIN1_Pin;		
	A_L.in2_pin = AIN2_Pin;
	
	D_R.in1_pin = DIN1_Pin;		
	D_R.in2_pin = DIN2_Pin;
	
	B_L.in1_pin = BIN1_Pin;		
	B_L.in2_pin = BIN2_Pin;
	
	C_R.in1_pin = CIN1_Pin;		
	C_R.in2_pin = CIN2_Pin;
	

//	PID_restart(&A_L.k_speed,20,5,0); 
//	PID_restart(&A_L.k_angle,50,0.5,0); 
//	
//	PID_restart(&D_R.k_speed,20,5,0); 	
//	PID_restart(&D_R.k_angle,50,0.5,0);	
//	
//	PID_restart(&B_L.k_speed,20,5,0);			
//	PID_restart(&B_L.k_angle,50,0.5,0);
//	
//	PID_restart(&C_R.k_speed,20,5,0);			
//	PID_restart(&C_R.k_angle,50,0.5,0);	

}


void MOTOR_Tim_Init(MOTOR_TypeDef *motor)
{		
	set_pid(&motor->k_speed, 20, 5, 0);
	set_pid(&motor->k_angle, 50, 0.5, 0);
	set_pid(&motor->k_double, 1.2, 0.005, 25);
	
	motor->actual_angle=0;
	motor->actual_speed=0;
	motor->target_angle=0;
	motor->target_speed=0;
	
	motor->encoder_overflow=0;
	motor->capture_count=0;
	motor->last_count=0;
	motor->pwm=0;

	
	__HAL_TIM_CLEAR_IT(&motor->encoder,TIM_IT_UPDATE);
	__HAL_TIM_SetCounter(&motor->encoder,0);		
	HAL_TIM_Base_Start_IT(&motor->encoder);		

	HAL_TIM_Encoder_Start(&motor->encoder, TIM_CHANNEL_1 | TIM_CHANNEL_2);	

	HAL_TIM_PWM_Start(&motor->timepwm1,motor->channelpwm1);
	
	motor->pwm = 0;
	set_motor_pwm(motor);
	delay_ms(500);
}


void MOTOR_Tim_Stop(MOTOR_TypeDef *motor)
{		
	motor->pwm = 0;
	set_motor_pwm(motor);

	motor->actual_angle=0;
	motor->actual_speed=0;
	motor->target_angle=0;
	motor->target_speed=0;
	
	motor->encoder_overflow=0;
	motor->capture_count=0;
	motor->last_count=0;
	motor->pwm=0;
	
	PID_init(&motor->k_angle);
	PID_init(&motor->k_speed);
	PID_init(&motor->k_double);
	

	HAL_TIM_Base_Stop_IT(&motor->encoder);			

}


void MOTOR_reset()	
{	
	MOTOR_Tim_Stop(&A_L);
	MOTOR_Tim_Stop(&B_L );
	MOTOR_Tim_Stop(&C_R );
	MOTOR_Tim_Stop(&D_R );
	
	delay_ms(50);
	
	MOTOR_Init();
	
	MOTOR_Tim_Init(&A_L );
	MOTOR_Tim_Init(&B_L );
	MOTOR_Tim_Init(&C_R ); 
	MOTOR_Tim_Init(&D_R );
}


float get_speed(float ns, MOTOR_TypeDef *motor) 
{		
	
	motor->capture_count = __HAL_TIM_GetCounter(&motor->encoder) + (motor->encoder_overflow*0xffff);	

	motor->actual_speed = (float) (motor->capture_count - motor->last_count) / (beipin*xianshu*jiansubi*ns); 
	
	motor->last_count = motor->capture_count;
	
	return motor->actual_speed;
}	

float get_angle(MOTOR_TypeDef *motor)
{		
	
	float angle=0;

	motor->capture_count = __HAL_TIM_GetCounter(&motor->encoder) + (motor->encoder_overflow*0xffff);	

	angle = 360.0f * (float)motor->capture_count/(beipin*xianshu*jiansubi);	
	
	return angle;			
}



void set_motor_pwm(MOTOR_TypeDef *motor)
{	


	if(motor->pwm < 0)
	{				
		HAL_GPIO_WritePin(motor->in1_port, motor->in1_pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(motor->in2_port, motor->in2_pin, GPIO_PIN_RESET);
	} else if(motor->pwm > 0)
	{				
		HAL_GPIO_WritePin(motor->in1_port, motor->in1_pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(motor->in2_port, motor->in2_pin, GPIO_PIN_SET);
		motor->pwm = -motor->pwm;		
	} else 
	{									
		HAL_GPIO_WritePin(motor->in1_port, motor->in1_pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(motor->in2_port, motor->in2_pin, GPIO_PIN_RESET);
	}
	

	if(motor->pwm > PWM_MAX) motor->pwm = PWM_MAX;
	

		__HAL_TIM_SetCompare(&motor->timepwm1, motor->channelpwm1, motor->pwm);

}	



void set_multiple_motors_pwm(MOTOR_TypeDef *motors, uint8_t count)
{
    for(uint8_t i = 0; i < count; i++) 
		{
        set_motor_pwm(&motors[i]);
    }
}

void stop_all_motors(MOTOR_TypeDef **motors, uint8_t count)
{
    for(uint8_t i = 0; i < count; i++)
		{
        motors[i]->pwm  = 0;
        set_motor_pwm(motors[i]);
    }
}

void set_all_motor_speeds(int16_t speeds[], uint8_t count) 
{
    if(count > MOTOR_COUNT) count = MOTOR_COUNT;
    
    for(uint8_t i = 0; i < count; i++) 
		{
        motors[i].pwm = speeds[i];
    }
    
    set_multiple_motors_pwm(motors, count);
}
void limit_pwm_angle(MOTOR_TypeDef *motor)
{
	if(motor->k_angle.integral <-(PWM_MAX/4) )motor->k_angle.integral = -(PWM_MAX/4);
	if(motor->k_angle.integral > (PWM_MAX/4) )motor->k_angle.integral = (PWM_MAX/4);
	
	if(motor->pwm <-(PWM_MAX) )motor->pwm = -(PWM_MAX);
	if(motor->pwm > (PWM_MAX) )motor->pwm = (PWM_MAX);
}

void limit_speed(MOTOR_TypeDef *motor)
{
	if(motor->target_speed > SPEED_MAX)motor->target_speed = SPEED_MAX;
	if(motor->target_speed < -SPEED_MAX)motor->target_speed = -SPEED_MAX;
}


void check_pwm_speed(MOTOR_TypeDef *motor){		
	float f = (motor->k_speed.fi / PWM_MAX) * SPEED_MAX;
	float v = motor->target_speed;
	
	if( -1.5f < f-v && f-v < 1.5f )return;		
	else motor->pwm = motor->k_speed.fi = ( v / SPEED_MAX ) * PWM_MAX;
}

/*
void feedback_angle(MOTOR_TypeDef *motor){
	motor->actual_angle = get_angle(motor);												
	motor->pwm = (int)PID_position(motor->target_angle, motor->actual_angle, PWM_MAX, &motor->k_angle);
	limit_pwm(motor);
	set_motor_pwm(motor);																
}
*/


void feedback_angle(MOTOR_TypeDef *motor){
	volatile float angle = get_angle(motor);
	volatile float target = motor -> target_angle;
	
	motor->pwm = (int)PID_position(target,angle, PWM_MAX/1.2, &motor->k_angle);
	
	motor->actual_angle = angle;
	limit_pwm_angle(motor);
	set_motor_pwm(motor);		
}

/*
void feedback_speed(MOTOR_TypeDef *motor){
	motor->actual_speed = get_speed(0.01,motor); 		//printf("actual speed=%f\r\n",motor->actual_speed);														
	motor->pwm = (int)PID_incremental(motor->target_speed*jiansubi, motor->actual_speed*jiansubi,  PWM_MAX, &motor->k_speed); 	
	//check_pwm_speed(&Back_L);																				
	set_motor_pwm(motor);																					
}
*/


void feedback_speed(MOTOR_TypeDef *motor)  
{
	volatile float speed = get_speed(0.01,motor); 
	volatile float target = motor ->target_speed;
	volatile int pwm=0;
	
	if( speed - (float)SPEED_MAX/1.5f > 0.5f ) speed = (float)SPEED_MAX/1.5f;	
	if( speed + (float)SPEED_MAX/1.5f < -0.5f) speed = -(float)SPEED_MAX/1.5f;
//	if( speed - motor->actual_speed > SPEED_MAX ) speed = motor->actual_speed + SPEED_MAX;	
//	if( speed - motor->actual_speed < -SPEED_MAX ) speed = motor->actual_speed - SPEED_MAX;
	
	motor -> actual_speed = speed;
	
	pwm = (int)PID_incremental(target*jiansubi, speed*jiansubi,  PWM_MAX/1.2, &motor->k_speed); 
	
	if(pwm > PWM_MAX/1.2) pwm = PWM_MAX/1.2;	
	if(pwm < -PWM_MAX/1.2)pwm = -PWM_MAX/1.2;
	
	motor->pwm = pwm;
	
	set_motor_pwm(motor);	
}

/*
void feedback_angle_double(MOTOR_TypeDef *motor, float ms){
	motor->actual_angle = get_angle(motor);	
	
	motor->target_speed = PID_position(motor->target_angle, motor->actual_angle, SPEED_MAX*jiansubi, &motor->k_double)/jiansubi; 
	limit_speed(motor);
	
	motor->actual_speed = (float) (motor->capture_count - motor->last_count) / (beipin*xianshu*jiansubi*ms); 
	motor->last_count = motor->capture_count;
	
	motor->pwm = (int)PID_incremental(motor->target_speed*jiansubi, motor->actual_speed*jiansubi, PWM_MAX, &motor->k_speed); 
		
	limit_pwm(motor);
	set_motor_pwm(motor);																
}
*/


void feedback_angle_double(MOTOR_TypeDef *motor, float ms)
{
	motor->actual_angle = get_angle(motor);	
	
	motor->target_speed = PID_position(motor->target_angle, motor->actual_angle, SPEED_MAX*jiansubi, &motor->k_double)/jiansubi; 
	
	if(motor->target_speed > (float)SPEED_MAX/3.0f ) motor->target_speed = (float)SPEED_MAX/3.0f;
	if(motor->target_speed < -(float)SPEED_MAX/3.0f ) motor->target_speed = -(float)SPEED_MAX/3.0f;
	
	motor->actual_speed = (float) (motor->capture_count - motor->last_count) / (beipin*xianshu*jiansubi*ms); 
	motor->last_count = motor->capture_count;
	
	motor->pwm = (int)PID_incremental(motor->target_speed*jiansubi, motor->actual_speed*jiansubi, PWM_MAX, &motor->k_speed); 
		
	limit_pwm_angle(motor);
	set_motor_pwm(motor);
}
