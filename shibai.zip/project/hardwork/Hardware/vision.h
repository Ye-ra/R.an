#ifndef __VISION_H_
#define __VISION_H_

#include "main.h"

void vision_control(u8 order);

#endif

