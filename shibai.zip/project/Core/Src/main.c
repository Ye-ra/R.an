/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
	*
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "Encoder.h"
#include "Motor.h" 
#include "PID.h"
#include <stdio.h>
#include "mpu6050.h" 
#include "delay.h"
#include <math.h> 
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/

/* USER CODE BEGIN PTD */

// 倾角阈值定义
#define TILT_THRESHOLD 10.0f      // 倾角阈值(度)，超过此值将调整PID参数
#define HIGH_TILT_THRESHOLD 30.0f // 大倾角阈值，可用于更激进的调整

// 全局PID增益系数
float pidPGainRatio = 1.0f;    // PID比例系数增益
float pidIGainRatio = 1.0f;    // PID积分系数增益
float pidDGainRatio = 1.0f;    // 可扩展的微分系数增益

// 倾角数据
float currentPitch = 0.0f;     // 当前俯仰角
float currentRoll = 0.0f;      // 当前横滚角
float currentYaw = 0.0f;       // 当前偏航角

// 全局变量
float lastMaxTilt = 0.0f;       // 上次倾角
float currentPGain = 1.0f;     // 当前P增益
float targetPGain = 1.0f;      // 目标P增益
float gainSmoothFactor = 0.1f; // 平滑因子（0.0-1.0，越小越平滑）

#define SAMPLING_TIME_MS 10    // PID采样时间(毫秒)
#define TARGET_SPEED 15.0f     // 目标速度(rpm)
#define RUNNING_TIME_MS 5000   // 运行时间(毫秒)
#define SPEED_TOLERANCE 1.5f   // 速度容差范围
 
#define MOTOR_COUNT 4
MOTOR_TypeDef motors[MOTOR_COUNT];

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */


// 电机ID枚举
typedef enum 
{
    MOTOR_A_L = 0,
    MOTOR_B_L = 1,
    MOTOR_C_R = 2,
    MOTOR_D_R = 3
} MotorID;
// 电机参数校准结构体
typedef struct 
{
    float speedOffset;     // 速度偏移补偿
    float pidP;            // 比例系数
    float pidI;            // 积分系数
    float pidD;            // 微分系数
} MotorCalibration;
const MotorCalibration motorCalibration[MOTOR_COUNT] = 
{
    {0.0f, 10.0f, 5.0f, 0.0f},  // 电机A校准参数
    {0.0f, 10.0f, 5.0f, 0.0f},  // 电机B校准参数
    {0.0f, 10.0f, 5.0f, 0.0f},  // 电机C校准参数
    {0.0f, 10.0f, 5.0f, 0.0f}   // 电机D校准参数
};


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

// 定义全局目标速度数组
float targetSpeeds[MOTOR_COUNT] = {0};



/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM8_Init();
  MX_TIM9_Init();
  MX_USART1_UART_Init();
  MX_USART3_UART_Init();
  MX_TIM1_Init();
 


/* USER CODE BEGIN 2 */
	MOTOR_Init ();
	//open 
	MOTOR_Tim_Init(&A_L);
	MOTOR_Tim_Init(&B_L);
	MOTOR_Tim_Init(&C_R);
	MOTOR_Tim_Init(&D_R);
	
	MPU_6050_Init();
  mpu_dmp_init(); // 初始化DMP获取姿态数据


	// 创建电机数组，便于循环操作
   MOTOR_TypeDef *motorPtrs[MOTOR_COUNT] ={ &A_L, &B_L, &C_R, &D_R };
	 
 // 初始化电机PID控制器
    for (int i = 0; i < MOTOR_COUNT; i++)
		{
        set_pid(&motors[i].k_speed, motorCalibration[i].pidP,motorCalibration[i].pidI, motorCalibration[i].pidD);
    }
    
		// 目标速度数组(+校准偏移)
    float targetSpeeds[MOTOR_COUNT];
		
    for (int i = 0; i < MOTOR_COUNT; i++)
		{
			targetSpeeds[i] = TARGET_SPEED + motorCalibration[i].speedOffset;
    }
    
    // 记录启动时间和上次更新时间
    uint32_t startTime = HAL_GetTick();
    uint32_t lastUpdateTime = startTime;
    
    // 速度一致性统计
    uint32_t consistentCount = 0;
    uint32_t totalCount = 0;


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
		while (1)
	{
		// 计算运行时间
        uint32_t currentTime = HAL_GetTick();
        uint32_t elapsedTime = currentTime - startTime;
        
        // 如果达到运行时间则停止
        if (elapsedTime >= RUNNING_TIME_MS)
					{
							stop_all_motors(motorPtrs, MOTOR_COUNT);	
					}
		 // 检查是否到达采样时间
        if (currentTime - lastUpdateTime >= SAMPLING_TIME_MS)
					{
							lastUpdateTime = currentTime;
							totalCount++;
							
							// 读取各电机实际速度
							float actualSpeeds[MOTOR_COUNT];
							for (int i = 0; i < MOTOR_COUNT; i++) 
							{
									actualSpeeds[i] = get_speed(SAMPLING_TIME_MS / 1000.0f, &motors[i]);
							}
							
							// 计算速度误差总和(用于协调控制)
							float speedErrorSum = 0;
							for (int i = 0; i < MOTOR_COUNT; i++)
							{
									speedErrorSum += targetSpeeds[i] - actualSpeeds[i];
							}
						
							//获取MPU6050倾角数据
            if (get_mpu_tilt_data() == 0) 
						{
                //根据倾角调整PID增益
                adjust_pid_gain_by_tilt();
                
//              //打印倾角数据（调试用）
//              printf("Tilt: Pitch=%.1f°, Roll=%.1f°, Yaw=%.1f°\r\n", 
//                       currentPitch, currentRoll, currentYaw);
            }	
						
						
							// 计算各电机PID输出(加入协调控制)
							int16_t motorPWM[MOTOR_COUNT];
							for (int i = 0; i < MOTOR_COUNT; i++)
							{
                
								// 临时修改PID参数
                float originalP  = motors[i].k_speed.p;
                float originalI  = motors[i].k_speed.i;
                
                // 应用增益
                motors[i].k_speed.p = originalP * pidPGainRatio;
                motors[i].k_speed.i= originalI * pidIGainRatio;
                
                // 计算PID输出
                motorPWM[i] = (int16_t)PID_incremental(targetSpeeds[i], actualSpeeds[i], PWM_MAX ,&motors[i].k_speed);
                
                // 恢复PID参数
                motors[i].k_speed.p  = originalP;
                motors[i].k_speed.i  = originalI;
                
                // 限幅保护
                if (motorPWM[i] >  PWM_MAX)  motorPWM[i] =  PWM_MAX;
								else if (motorPWM[i] < -PWM_MAX)  motorPWM[i] = -PWM_MAX;
            }
							 // 设置所有电机PWM输出
            set_all_motor_speeds(motorPWM, MOTOR_COUNT);
            
            // 检查速度一致性
            float speedDeviation = 0;
            for (int i = 0; i < MOTOR_COUNT - 1; i++)
						{
                for (int j = i + 1; j < MOTOR_COUNT; j++)
								{
                    speedDeviation += fabs(actualSpeeds[i] - actualSpeeds[j]);
                }
            }
						
            speedDeviation /= (MOTOR_COUNT * (MOTOR_COUNT - 1) / 2);
            
            if (speedDeviation < SPEED_TOLERANCE) 
						{
                consistentCount++;
            }

						
			}
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */


		}
}
 	/**
 * 读取MPU6050倾角数据并更新全局变量
 * @return 0:成功 非0:失败
 */
unsigned char get_mpu_tilt_data(void) 
{
    return mpu_dmp_get_data(&currentPitch, &currentRoll, &currentYaw);
}
	
/**
 * 根据当前倾角调整PID增益系数
 * 逻辑：倾角越大，PID增益越低，防止小车侧翻
 */
void adjust_pid_gain_by_tilt(void) 
{
    // 计算综合倾角（取俯仰角和横滚角的绝对值最大值）
    float maxTilt = fmaxf(fabsf(currentPitch), fabsf(currentRoll));
    
    // 根据倾角大小动态调整PID增益
    if (maxTilt < TILT_THRESHOLD) 
		{
        // 小倾角，使用正常增益
        pidPGainRatio = 1.0f;
        pidIGainRatio = 1.0f;
    } else if (maxTilt < HIGH_TILT_THRESHOLD)
		{
        // 中等倾角，降低增益
        pidPGainRatio = 0.7f;
        pidIGainRatio = 0.5f;
    } else 
		{
        // 大倾角，大幅降低增益并限制速度
        pidPGainRatio = 0.3f;
        pidIGainRatio = 0.2f;
        
        // 大倾角时额外限制目标速度
        for (int i = 0; i < MOTOR_COUNT; i++) 
			  {
            targetSpeeds[i] = TARGET_SPEED * 0.5f + motorCalibration[i].speedOffset;
        }
    }
}

//平滑
void adjust_pid_gain_by_tilt_smooth(void)
{
    float maxTilt = fmaxf(fabsf(currentPitch), fabsf(currentRoll));
    
    // 根据倾角计算目标增益
    if (maxTilt < TILT_THRESHOLD)
		{
        targetPGain = 1.0f;
    } 
		else if (maxTilt < HIGH_TILT_THRESHOLD) 
		{
        targetPGain = 0.7f;
    } 
		else 
		{
        targetPGain = 0.3f;
    }
    
    // 平滑过渡增益（避免阈值附近抖动）
    currentPGain = currentPGain * (1.0f - gainSmoothFactor) + targetPGain * gainSmoothFactor;
    pidPGainRatio = currentPGain;
}
/* USER CODE END 3 */


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */

  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

