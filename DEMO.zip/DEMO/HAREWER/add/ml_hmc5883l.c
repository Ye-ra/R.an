#include "ml_hmc5883l.h"
#include "i2c.h"

int16_t hmc_x, hmc_y, hmc_z;
float yaw_hmc;


/**
 * @brief test code to write mpu6050
 *
 * 1. send data
 * ___________________________________________________________________________________________________
 * | start | slave_addr + wr_bit + ack | write reg_address + ack | write data_len byte + ack  | stop |
 * --------|---------------------------|-------------------------|----------------------------|------|
 **/
void HMC_Send(uint8_t *data, uint8_t len)
{
  HAL_I2C_Master_Transmit(&hi2c2, HMC5883L_ADDR, data, len, HAL_MAX_DELAY);
}

void HMC5883L_Write(uint8_t reg_add,uint8_t reg_dat)
{
  static uint8_t sendBuffer[2] = {0};
	sendBuffer[0] = reg_add;
  sendBuffer[1] = reg_dat;
  HMC_Send(sendBuffer, 2);
}

/**
 * @brief test code to read mpu6050
 *
 * 1. send reg address
 * ______________________________________________________________________
 * | start | slave_addr + wr_bit + ack | write reg_address + ack | stop |
 * --------|---------------------------|-------------------------|------|
 *
 * 2. read data
 * ___________________________________________________________________________________
 * | start | slave_addr + wr_bit + ack | read data_len byte + ack(last nack)  | stop |
 * --------|---------------------------|--------------------------------------|------|
 **/
void HMC_Read(uint8_t reg_add,uint8_t *data, uint8_t len)
{
	static uint8_t sendBuffer[1] = {0};
	sendBuffer[0] = reg_add;
	HMC_Send(sendBuffer,1);
	
	HAL_I2C_Master_Receive(&hi2c2,HMC5883L_ADDR,data,len,HAL_MAX_DELAY);
}




uint8_t HMC5883L_Read(uint8_t addr)
{

	uint8_t dat;
	HMC_Read(addr,&dat,1);
	
	return dat;
}

void HMC5883L_Init()
{
	HMC5883L_Write(HMC5883L_CRA, 0xf8);  // ���������ʣ�75HZ��
	HMC5883L_Write(HMC5883L_CRB, 0x20);  // Ĭ������
	HMC5883L_Write(HMC5883L_MR, 0x00);   // ��������
}

void HMC5883L_GetData()
{
	uint8_t data_h, data_l;
	data_h = HMC5883L_Read(HMC5883L_DOXMR);
	data_l = HMC5883L_Read(HMC5883L_DOXLR);
	hmc_x = data_l | (data_h << 8);

	data_h = HMC5883L_Read(HMC5883L_DOYMR);
	data_l = HMC5883L_Read(HMC5883L_DOYLR);
	hmc_y = data_l | (data_h << 8);

	data_h = HMC5883L_Read(HMC5883L_DOZMR);
	data_l = HMC5883L_Read(HMC5883L_DOZLR);
	hmc_z = data_l | (data_h << 8);
}




	


