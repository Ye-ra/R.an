#include "interrupt_main.h"
#include "tim.h"
#include "usart.h"
#include "mympu6050.h"
#include "ml_hmc5883l.h"


static void USART_Proc(void);


uint8_t i=0; 
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	if(htim == &htim6){//5ms�ж�һ��
		i++;
		App_MPU6050_Proc();
		//��ȡԭʼ����
		HMC5883L_GetData();
		//��������ƽǶ�
		yaw_hmc = atan2((float)hmc_x,(float)hmc_y) * 57.296;
		

		if(i%2==0){//10msִ��һ��
			USART_Proc();
		}
		if(i>=125) i=0;
	}
}

static void USART_Proc(void){
	float accel[3],temperature,gyro[3],eular[3];
	App_MPU6050_GetResult(accel,&temperature,gyro,eular);
//	myprintf("kalman:%.2f,%.2f,%.2f\n",yaw_Kalman,pitch_Kalman,roll_Kalman);
//	myprintf("yaw_hmc:%.2f\n",yaw_hmc);
	myprintf( "$%.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f;\r\n", 
	  accel[0],accel[1],accel[2],
		gyro[0],gyro[1],gyro[2],
		eular[0],eular[1],eular[2],
		temperature);
}