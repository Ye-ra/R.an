#include "pwm.h"
#include "math.h"
#include <stdlib.h>

/**************************************************************************
�������ܣ�pwm��ʼ��
��ڲ�����arr����Ϊһ��ʱ��Ƶ�ʵ����ֵ  psc�� Ԥ��Ƶֵ
����  ֵ����
**************************************************************************/
void PWM_Int(u16 arr,u16 psc)
{
	GPIO_InitTypeDef GPIO_InitStructure;                //����ṹ��GPIO_InitStructure
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;      //����ṹ��TIM_TimeBaseStructure   
	TIM_OCInitTypeDef TIM_OCInitStructure;              //����ṹ��TIM_OCInitStructure
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB,ENABLE);//ʹ�ܶ˿�ʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);//ʹ�ܶ�ʱ��2
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);//ʹ�ܶ�ʱ��3	
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_2|GPIO_Pin_3;  //A B
	GPIO_InitStructure.GPIO_Speed= GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1; // C  D
	GPIO_InitStructure.GPIO_Speed= GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	TIM_TimeBaseStructure.TIM_Period = arr;                //������һ�����»���Զ���װ�ؼĴ�����ֵ
	TIM_TimeBaseStructure.TIM_Prescaler = psc;             //Ԥ����ֵ
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;           //ʱ�ӷָ�
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //���ϼ���

  TIM_TimeBaseInit(TIM2,&TIM_TimeBaseStructure);  // tim2
	TIM_OCInitStructure.TIM_OCMode= TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; 
	
	TIM_OC1Init(TIM2,&TIM_OCInitStructure); //PA2
	TIM_OC2Init(TIM2,&TIM_OCInitStructure); //PA3
	
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseStructure);	//tim3
	TIM_OC3Init(TIM3,&TIM_OCInitStructure); //PB0
	TIM_OC4Init(TIM3,&TIM_OCInitStructure); //PB1
	
	
	TIM_OC1PreloadConfig(TIM2,TIM_OCPreload_Enable);
	TIM_OC2PreloadConfig(TIM2,TIM_OCPreload_Enable);
	TIM_OC3PreloadConfig(TIM3,TIM_OCPreload_Enable);
	TIM_OC4PreloadConfig(TIM3,TIM_OCPreload_Enable);//ʹ��Ԥװ�ؼĴ���

	TIM_Cmd(TIM2,ENABLE);//������ʱ��
	TIM_Cmd(TIM3,ENABLE);
	
	TIM_ARRPreloadConfig(TIM2,ENABLE);              //ʹ���Զ�װ������λ
	TIM_ARRPreloadConfig(TIM3,ENABLE);

//ʹ�����
  TIM_CtrlPWMOutputs (TIM2 , ENABLE );
  TIM_CtrlPWMOutputs (TIM3 , ENABLE );
	

}
int myabs(int value){
	if (value<0) value=-value;
	return value;
}
void Set_PWM(int motor1,int motor2,int motor3,int motor4)
{
	if(motor1>0){
		GPIO_SetBits(GPIOB, GPIO_Pin_9);	    // �ߵ�ƽ     PB9 --- AIN2      1   
		GPIO_ResetBits(GPIOB, GPIO_Pin_8);	 // �͵�ƽ      PB8 --- AIN1      0
	  
	}
	else
	{
		 GPIO_SetBits(GPIOB, GPIO_Pin_8);	    // �ߵ�ƽ    PB8 --- AIN1     1
	   GPIO_ResetBits(GPIOB, GPIO_Pin_9);	 // �͵�ƽ     PB9 --- AIN2     0
	}
	if(motor2>0)
	{
			GPIO_SetBits(GPIOB, GPIO_Pin_5);      //�ߵ�ƽ   PB5 --- BIN2       1
			GPIO_ResetBits(GPIOB, GPIO_Pin_4);   // �͵�ƽ   PB4 --- BIN1       0
	}
	else
	{
		GPIO_SetBits(GPIOB, GPIO_Pin_4);       //�ߵ�ƽ  PB4 --- BIN1     1
		GPIO_ResetBits(GPIOB, GPIO_Pin_5);   // �͵�ƽ   PB5 --- BIN2        0
	}
	if(motor3>0)
	{
		GPIO_SetBits(GPIOB, GPIO_Pin_13);     //�ߵ�ƽ   PB13 --- CIN2       1
	  GPIO_ResetBits(GPIOB, GPIO_Pin_12);  // �͵�ƽ   PB12 --- CIN1       0
	}
	else
	{
	  GPIO_SetBits(GPIOB, GPIO_Pin_12);     //�ߵ�ƽ   PB12 --- CIN1       1
		GPIO_ResetBits(GPIOB, GPIO_Pin_13);  // �͵�ƽ   PB13 --- CIN2       0
	}
	if(motor4>0)
		{
			GPIO_SetBits(GPIOB, GPIO_Pin_15);     //�ߵ�ƽ   PB15 --- DIN2       1
			GPIO_ResetBits(GPIOB, GPIO_Pin_14);  // �͵�ƽ   PB14 --- DIN1       0
	}
	else
	{
		GPIO_SetBits(GPIOB, GPIO_Pin_14);      //�ߵ�ƽ   PB14 --- DIN1       1
		GPIO_ResetBits(GPIOB, GPIO_Pin_15);   // �͵�ƽ   PB15 --- DIN2       0
	}
	  TIM_SetCompare1(TIM2,myabs(motor1));
	  TIM_SetCompare2(TIM2,myabs(motor2));
    TIM_SetCompare3(TIM3,myabs(motor3));   //����TIM3ͨ��3��ռ�ձ�  3000/7200
    TIM_SetCompare4(TIM3,myabs(motor4));
	
}



